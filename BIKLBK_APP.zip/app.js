const firebaseConfig = {
  apiKey: "AIzaSyC9YUChChiiC6HZbPvYyRvT8oV68_5IDDE",
  authDomain: "biklbik-2548a.firebaseapp.com",
  databaseURL: "https://biklbik-2548a-default-rtdb.firebaseio.com",
  projectId: "biklbik-2548a",
  storageBucket: "biklbik-2548a.firebasestorage.app",
  messagingSenderId: "831765962208",
  appId: "1:831765962208:web:84e602dc9e596947795f85"
};
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.database();
const ACTIVATION_CODE = "z3imhamdi";
function checkCode(){
  const code = document.getElementById("activeCode").value;
  if(code!==ACTIVATION_CODE){document.getElementById("errorMsg").innerText="❌ كود التفعيل غير صحيح"; return false;}
  return true;
}
function loginEmail(){
  if(!checkCode()) return;
  const email=emailInput.value, pass=passwordInput.value;
  auth.signInWithEmailAndPassword(email,pass)
    .then(()=>openHome())
    .catch(e=>document.getElementById("errorMsg").innerText=e.message);
}
function signupEmail(){
  if(!checkCode()) return;
  const email=emailInput.value, pass=passwordInput.value;
  auth.createUserWithEmailAndPassword(email,pass)
    .then(()=>openHome())
    .catch(e=>document.getElementById("errorMsg").innerText=e.message);
}
function loginGoogle(){
  if(!checkCode()) return;
  const provider = new firebase.auth.GoogleAuthProvider();
  auth.signInWithPopup(provider).then(()=>openHome()).catch(e=>document.getElementById("errorMsg").innerText=e.message);
}
function openHome(){
  document.getElementById("loginScreen").style.display="none";
  document.getElementById("home").style.display="block";
  loadPosts();
}
function addPost(){
  const text=document.getElementById("postText").value;
  const file=document.getElementById("postFile").files[0];
  if(!text && !file) return;
  const postRef=db.ref("posts").push();
  if(file){
    const storageRef=firebase.storage().ref("posts/"+Date.now()+"_"+file.name);
    storageRef.put(file).then(snap=>snap.ref.getDownloadURL().then(url=>{
      postRef.set({user:auth.currentUser.email,text,text,media:url,type:file.type.includes("video")?"video":"image",time:Date.now()});
    }));
  } else {
    postRef.set({user:auth.currentUser.email,text,text,time:Date.now()});
  }
  document.getElementById("postText").value="";
  document.getElementById("postFile").value="";
  loadPosts();
}
function loadPosts(){
  db.ref("posts").once("value", snap=>{
    const posts=snap.val(); let html='';
    for(let id in posts){
      let p=posts[id];
      let media='';
      if(p.media){media=p.type==="video"?`<video src="${p.media}" controls></video>`:`<img src="${p.media}">`; }
      html+=`<div class="post"><b>${p.user.split("@")[0]}</b><p>${p.text}</p>${media}</div>`;
    }
    document.getElementById("posts").innerHTML=html;
  });
}
function goProfile(){window.location="profile.html";}